const RTS_URLS = [
  "https://offers.rts-tender.ru/",
  "https://offers.rts-tender.ru/supplier/price-lists",
  "https://offers.rts-tender.ru/supplier/price-lists/positions",
  "https://platform.rts-tender.ru/",
  "https://app.rts-tender.ru/",
  "https://www.rts-tender.ru/",
  "https://rts-tender.ru/",
];
const RTS_DOMAINS = [
  ".rts-tender.ru",
  "rts-tender.ru",
  "offers.rts-tender.ru",
  "platform.rts-tender.ru",
  "app.rts-tender.ru",
];

function setStatus(text, ok) {
  const el = document.getElementById("status");
  el.textContent = text;
  el.className = ok === true ? "ok" : ok === false ? "err" : "";
}

function normalizeCookieText(raw) {
  let text = String(raw || "").trim();
  if (!text) return "";
  if (text.toLowerCase().startsWith("cookie:")) {
    text = text.slice("cookie:".length).trim();
  }
  return text;
}

function cookieFromManual(raw) {
  const text = normalizeCookieText(raw);
  if (!text) return null;
  const pairs = text.split(";").map((p) => p.trim()).filter(Boolean);
  const cookies = [];
  for (const pair of pairs) {
    const idx = pair.indexOf("=");
    if (idx <= 0) continue;
    const name = pair.slice(0, idx).trim();
    const value = pair.slice(idx + 1).trim();
    if (name) cookies.push({ name, value });
  }
  if (!cookies.length) {
    throw new Error("Не удалось разобрать строку Cookie.");
  }
  return { cookie: text, cookies, source: "manual" };
}

async function collectCookiesAuto() {
  const seen = new Map();
  const urls = new Set(RTS_URLS);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes("rts-tender.ru")) {
      urls.add(tab.url);
      const origin = tab.url.split("/").slice(0, 3).join("/") + "/";
      urls.add(origin);
    }
  } catch (_) {
    /* tabs permission missing or unavailable */
  }

  for (const url of urls) {
    const items = await chrome.cookies.getAll({ url });
    for (const c of items) {
      if (c.name && c.value != null) {
        seen.set(c.name, c.value);
      }
    }
  }
  for (const domain of RTS_DOMAINS) {
    const items = await chrome.cookies.getAll({ domain });
    for (const c of items) {
      if (c.name && c.value != null) {
        seen.set(c.name, c.value);
      }
    }
  }
  if (!seen.size) {
    throw new Error("Cookie не найдены. Вставьте Cookie из DevTools (Network) или войдите на offers.rts-tender.ru.");
  }
  const cookies = [...seen.entries()].map(([name, value]) => ({ name, value }));
  const cookie = cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  return { cookie, cookies, source: "auto", names: [...seen.keys()] };
}

async function resolveCookiePayload() {
  const manual = document.getElementById("cookieManual").value.trim();
  if (manual) {
    return cookieFromManual(manual);
  }
  return collectCookiesAuto();
}

async function loadSettings() {
  const data = await chrome.storage.sync.get(["apiUrl", "apiKey", "profile"]);
  if (data.apiUrl) document.getElementById("apiUrl").value = data.apiUrl;
  if (data.apiKey) document.getElementById("apiKey").value = data.apiKey;
  if (data.profile) document.getElementById("profile").value = data.profile;
}

async function saveSettings() {
  const apiUrl = document.getElementById("apiUrl").value.trim();
  const apiKey = document.getElementById("apiKey").value.trim();
  const profile = document.getElementById("profile").value.trim();
  await chrome.storage.sync.set({ apiUrl, apiKey, profile });
}

async function sendCookies() {
  const apiUrl = document.getElementById("apiUrl").value.trim();
  const apiKey = document.getElementById("apiKey").value.trim();
  const profile = document.getElementById("profile").value.trim();
  if (!apiUrl || !apiKey) {
    setStatus("Укажите URL API и API key.", false);
    return;
  }
  if (!profile) {
    setStatus("Выберите профиль (IPSokolova или Nacpro).", false);
    return;
  }
  await saveSettings();
  setStatus("Подготовка cookie…", null);
  try {
    const payload = await resolveCookiePayload();
    const count = payload.cookies.length;
    const note =
      payload.source === "manual"
        ? `ручная вставка, ${count} cookie`
        : `авто-сбор, ${count} cookie: ${(payload.names || []).join(", ")}`;
    setStatus(`Отправка (${note})…`, null);

    const r = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": apiKey,
      },
      body: JSON.stringify({
        cookie: payload.cookie,
        cookies: payload.cookies,
        profile,
        source: payload.source === "manual" ? "rts-cookie-bridge-manual" : "rts-cookie-bridge",
      }),
    });
    const text = await r.text();
    let data = {};
    try {
      data = JSON.parse(text);
    } catch (_) {
      data = { message: text };
    }
    if (!r.ok) {
      setStatus(data.detail || data.message || `HTTP ${r.status}`, false);
      return;
    }
    let probe = "probe: проверьте сессию";
    const probeOk = !!(data.probe && data.probe.ok);
    if (probeOk) {
      probe = data.probe.channel === "offers" ? "probe OK (offers)" : "probe OK";
    } else if (data.probe && data.probe.reason === "empty_page") {
      probe =
        "probe: неполная сессия — скопируйте Cookie из Network (запрос Ktru/search или draft/create)";
    } else if (data.probe && data.probe.reason) {
      probe = `probe: ${data.probe.reason}`;
    }
    const warn =
      payload.source !== "manual" && count < 12
        ? `\nСовет: авто-сбор дал мало cookie — используйте вставку из DevTools.`
        : "";
    setStatus(`${data.message || "OK"}\n${note}\n${probe}${warn}`, probeOk);
  } catch (e) {
    setStatus(String(e.message || e), false);
  }
}

document.getElementById("sendBtn").addEventListener("click", sendCookies);
loadSettings();
